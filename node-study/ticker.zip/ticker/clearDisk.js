/**
 * @file 定时清理磁盘文件
 * @author hwm
 */
const schedule = require('node-schedule');
const {exec} = require('child_process');
const chalk = require('chalk');

/**
 * scheduleJob 规则参数讲解
 *  *  *  *  *  *
 ┬ ┬ ┬ ┬ ┬ ┬
 │ │ │ │ │ │
 │ │ │ │ │ └ day of week (0 - 7) (0 or 7 is Sun)
 │ │ │ │ └───── month (1 - 12)
 │ │ │ └────────── day of month (1 - 31)
 │ │ └─────────────── hour (0 - 23)
 │ └──────────────────── minute (0 - 59)
 └───────────────────────── second (0 - 59, OPTIONAL)
 */
const scheduleCronstyle = () => {
    // 每周1，中午12:00:00，清空指定目录
    schedule.scheduleJob('00 00 12 * * 1', () => {
        console.log('scheduleCronstyle:' + new Date());
        const path = '/Users/huangwenming/hwm/home/htdocs/git/learning-notes/node-study/ticker/test';
        console.log(`start: clear disk: ${path}`);
        clearDisk(path);
        console.log(`end: clear disk: ${path}`);
    });
};
const clearDisk = dir => {
    if (dir) {
        exec(`rm -rf ${dir}`, (err, stdout, stderr) => {
            if (err) {
                console.log(`${chalk.red(err)}`);
                process.exit();
            }
            console.log(`stdout: ${stdout}`);
            console.log(`stderr: ${stderr}`);
        });
    }
};
scheduleCronstyle();
